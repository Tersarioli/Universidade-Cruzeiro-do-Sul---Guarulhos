/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()

{
    float a, b, c;
    float delta, x1, x2;
    
    printf("Digite o valor de a: ");
    scanf("%f", &a);
    
    printf("Digite o valor de b: ");
    scanf("%f", &b);
    
    printf("Digite o valor de c: ");
    scanf("%f", &c);
    
    delta = b*b-4*a*c;
    x1 = (-b + sqrtf(delta))/2*a;
    x2 = (-b - sqrtf(delta))/2*a;
    
    printf("\n O valor da primeira raiz é %.2f", x1);
    printf("\n O valor da segunda raiz é %.2f", x2);
    
    return 0;
    
}